import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-match',
  templateUrl: 'match.html'
})
export class MatchPage {

  constructor(public navCtrl: NavController) {

  }

}
